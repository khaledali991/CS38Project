//function onclick(){
  //  document.getElementById('img_history').document

function signup(){

  document.getElementById('login').setAttribute('style','display:none');
  document.getElementById('signup').setAttribute('style','display:block');
}

function login(){

  document.getElementById('login').setAttribute('style','display:block');
  document.getElementById('signup').setAttribute('style','display:none');
}