<?php 

$user = "root";
$password = "";
$host = "localhost";
$db = "books";

$conn = mysqli_connect($host, $user, $password, $db);
?>
