
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Book library</title>
    <link rel="stylesheet" type="text/css" href="library1.css">
        <script src="library1.js"></script>

    
</head>
<body>

<?php 
@include ('conect.php');
if(isset($_POST['submit'])){                
  
    $username = $_POST['username'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    
    $sql = "SELECT * FROM booklog WHERE username='$username' AND password='$password'";
      $info = mysqli_query($conn, $sql);
  if (mysqli_num_rows($info) > 0) { 
    echo "user already exist!";
  }
    else if($password != $confirm_password){
      echo "password not matched!";
  
    }
     else {
      $sql = " INSERT into booklog ( username ,password) values ( '$username', '$password')";
      $result = mysqli_query($conn, $sql);    
      header('location:login.php');
     }
}

?>

<div class="center">
     <div ALIGN="center">
    <h1>Signup</h1>
    <form action="" method="post">
    	<div class="txt_field" >
   	  Username:<input type="text" required name="username">
			 </div>
	<div class="txt_field" >
	Password:<input type="password" required name="password"><br>
		</div>
             Confirm Password :
             <input type="password" required name="confirm_password">
		   </div>
           <input type="submit" value="signup" name="submit">
	<div class="signup_link">
	Already a member? <a href="login.php">Login</a>
	</div>
	</form>
	</div>
</div>
</body>
</html>
 