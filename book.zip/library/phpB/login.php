<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Book library</title>
    <link rel="stylesheet" type="text/css" href="library1.css">
    <script src="library1.js"></script>
</head>
<body>
  
<?php
@include ('conect.php');
   session_start();
if(isset($_POST['submit'])){
  $username = $_POST['username'];
  $password = $_POST['password'];    
  
  $sql = "SELECT * FROM booklog WHERE username='$username' AND password='$password'";

  $info = mysqli_query($conn, $sql);
  if (mysqli_num_rows($info) > 0) { 
    $row = mysqli_fetch_array($info);
       
    if ($row['username'] === $username && $row['password'] === $password) {
      echo "is vaild login ";
    }
  }
  else{
    echo  "Incorrect Username or password";
  }

}
  ?>
  
<div class="center" id="login">
  <div ALIGN="center" >
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
	<h1>Login</h1>
  <br>
	<form action=""  method="post" >
       <div class="txt_field">
                Username:<input type="text" required name="username"><br>
       </div>
       <br>
       
         <div class="txt_field">
                Password:<input type="password" id ="password"required name="password"><br>
           </div>
           <br>
           <input type="submit" value="login" name="submit">
           <br>
           <div class="signup_link">
           Not a member? <a href="index.php?j=signup">Signup</a>     </div>
       </form>
      </div>
</body>
</html>
 